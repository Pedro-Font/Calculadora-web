using System;

namespace CalculadoraWeb.Models
{
    public class CalculadoraModel
    {
        public double Resultado { get; set; }

        public double Suma(double a, double b) => a + b;
        public double Resta(double a, double b) => a - b;
        public double Multiplicacion(double a, double b) => a * b;
        public double Division(double a, double b) => b != 0 ? a / b : throw new DivideByZeroException();
        
        public double Cuadrado(double x) => Math.Pow(x, 2);
        public double RaizCuadrada(double x) => Math.Sqrt(x);
        public double Potencia(double baseNum, double exponente) => Math.Pow(baseNum, exponente);
        public double DiezALaX(double x) => Math.Pow(10, x);
        public double Logaritmo(double x) => Math.Log10(x); // Logaritmo base 10

        
        
        
        // Otros métodos matemáticos avanzados según sea necesario
    }
}



