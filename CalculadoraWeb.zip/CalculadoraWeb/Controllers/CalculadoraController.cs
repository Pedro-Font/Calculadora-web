using Microsoft.AspNetCore.Mvc;
using CalculadoraWeb.Models;
using Microsoft.AspNetCore.Http;
using NCalc;
using System;
using System.Linq;

namespace CalculadoraWeb.Controllers
{
    public class CalculadoraController : Controller
    {
        private readonly CalculadoraModel _calculadora;

        public CalculadoraController()
        {
            _calculadora = new CalculadoraModel();
        }

        public IActionResult Index()
        {
            ViewBag.Input = HttpContext.Session.GetString("Input") ?? "";
            return View();
        }

        [HttpPost]
        public IActionResult Calcular(string button)
        {
            try
            {
                string input = HttpContext.Session.GetString("Input") ?? "";
                string numeroBase = HttpContext.Session.GetString("NumeroBase");
                string operador = HttpContext.Session.GetString("Operador");

                switch (button)
                {
                    case "=":
                        if (!string.IsNullOrEmpty(numeroBase) && !string.IsNullOrEmpty(input) && !string.IsNullOrEmpty(operador))
                        {
                            double baseNum = double.Parse(numeroBase);
                            double segundoNum = double.Parse(input);
                            switch (operador)
                            {
                                case "+":
                                    ViewBag.Resultado = _calculadora.Suma(baseNum, segundoNum);
                                    break;
                                case "-":
                                    ViewBag.Resultado = _calculadora.Resta(baseNum, segundoNum);
                                    break;
                                case "*":
                                    ViewBag.Resultado = _calculadora.Multiplicacion(baseNum, segundoNum);
                                    break;
                                case "/":
                                    ViewBag.Resultado = _calculadora.Division(baseNum, segundoNum);
                                    break;
                                default:
                                    throw new InvalidOperationException("Operador no válido.");
                            }
                            input = ViewBag.Resultado.ToString();
                            HttpContext.Session.Remove("NumeroBase"); // Limpiar la sesión después de usarla
                            HttpContext.Session.Remove("Operador");
                        }
                        else
                        {
                            ViewBag.Error = "Debe ingresar un número base, un operador y un segundo número para realizar la operación.";
                        }
                        break;
                    case "C":
                        input = "";
                        ViewBag.Resultado = null;
                        HttpContext.Session.Remove("NumeroBase"); // Limpiar la sesión si se cancela
                        HttpContext.Session.Remove("Operador");
                        break;
                    case "+":
                    case "-":
                    case "*":
                    case "/":
                        // Guardar el número base y el operador
                        HttpContext.Session.SetString("NumeroBase", input);
                        HttpContext.Session.SetString("Operador", button);
                        input = "";
                        break;
                    case "^":
                        // Guardar el número base en la sesión
                        HttpContext.Session.SetString("NumeroBase", input);
                        input = "";
                        break;
                    case "x²":
                        ViewBag.Resultado = _calculadora.Cuadrado(double.Parse(input));
                        input = ViewBag.Resultado.ToString();
                        break;
                    case "√":
                        ViewBag.Resultado = _calculadora.RaizCuadrada(double.Parse(input));
                        input = ViewBag.Resultado.ToString();
                        break;
                    case "10^x":
                        ViewBag.Resultado = _calculadora.DiezALaX(double.Parse(input));
                        input = ViewBag.Resultado.ToString();
                        break;
                    case "log":
                        ViewBag.Resultado = _calculadora.Logaritmo(double.Parse(input));
                        input = ViewBag.Resultado.ToString();
                        break;
                    default:
                        input += button;
                        break;
                }

                HttpContext.Session.SetString("Input", input);
                ViewBag.Input = input;
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }

            return View("Index");
        }
    }
}












